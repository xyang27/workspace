<!DOCTYPE html>
  <html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
<!--     <link rel="icon" href="http://v3.bootcss.com/favicon.ico"> -->
    <title>Stevens Now</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
  </head>

  <body>
      <?php
        require("common_nav.php");
      ?>

    <div class="container">
    <div class="jumbotron">
    <form class="form-horizontal" action="user_sign_up.php" method="post" id="userSignUp" role="form">
      <div class="form-group">
        <label for="inputEmail3" class="col-sm-2 control-label">Username</label>
        <div class="col-sm-5">
          <input type="text" class="form-control" id="sign_username" name="sign_username" placeholder="Username">
        </div>
      </div>
      <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Password</label>
        <div class="col-sm-5">
          <input type="password" class="form-control" id="sign_password" name="sign_password"placeholder="Password">
        </div>
      </div>

      <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Password Confirm</label>
        <div class="col-sm-5">
          <input type="password" class="form-control" id="sign_password_confirm" name="sign_password_confirm"placeholder="Password Confirm">
        </div>
      </div>

      <div class="form-group">
        <label for="inputPassword3" class="col-sm-2 control-label">Email</label>
        <div class="col-sm-5">
          <input type="text" class="form-control" id="email" name="email" placeholder="Email">
        </div>
      </div>

      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-5">
          <button type="submit" class="btn btn-primary btn-default">Submit</button>
        </div>
      </div>
    </form>
    </div>
    
    </div><!-- /.container -->

    <script src = "js/jquery-1.11.1.min.js"></script>
    <script src = "js/jquery.validate.min.js"></script>
    <script src = "js/bootstrap.min.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){

        $("#userSignUp").validate({
          rules:{
            sign_username:{
              required:true,
              minlength:5,
              remote:{
                url:"is_username_exist.php",
                type:"post",
                data: {
                  username: function() {
                    return $( "#sign_username" ).val();
                  }
                }
              }},
                sign_password:{required:true},
                sign_password_confirm:{required:true,equalTo: "#sign_password"},
                email:{required:true,email:true}
          },
          messages:{
            username:{
              required:"This filed must be filled",
              minlength:"It's too short",
              remote: "The username already exists"
            },
            password_confirm:{equalTo:"Please Confirm the Password"}
          }
        });

        // $("#userSignUp").validate({
        //     rules:{
        //     username:{required:true,
        //       minlength:5,
        //       remote:{
        //         url:"is_username_exist.php",
        //         type:"post",
        //         data:{
        //           username:function(){return $("#username").val();}
        //         }
        //       }
        //     },
        //     password:{required:true},
        //     password_confirm:{required:true,equalTo: "#password"},
        //     email:{required:true,email:true}
        //   },
        //   messages:{
        //     username:{remote:"Username already exists"},
        //     password_confirm:{equalTo:"Please Confirm the Password"}
        //   }
        // });
      });  
    </script>
</body>
</html>