<?php

	include("./include/databaseClassMySQLi.php");
	include("./include/common.php");
	include("./include/DataStructure/user.php");

	if (isset($_POST["username"]) && isset($_POST["password"])) {
		SignIn($_POST["username"], $_POST["password"]);
	}else{
		header("location: main.php");
	}


	function SignIn($n, $p)
	{
		$db = new database();
		$db->connect();
		$query = "SELECT * FROM user WHERE username = '".$n."' AND password = '".$p."';";
		if (! $res = $db->send_sql($query)) {
			echo "Database Problem";
			exit();
		}
		$count = mysqli_num_rows($res);
		if ($count > 0) {
			session_start();
			$row = $db->next_row();
			$_SESSION["id_user"] = $row["id_user"];
			$_SESSION["username"] = $row["username"];
			header("location: main.php");
			
		}else{
			header("location: main.php");
		}
	}
?>