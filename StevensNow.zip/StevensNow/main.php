<!DOCTYPE html>
  <html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
<!--     <link rel="icon" href="http://v3.bootcss.com/favicon.ico"> -->
    <title>Stevens Now</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link rel="stylesheet" type="text/css" href="css/mainpage.css">
    <link rel="stylesheet" type="text/css" href="css/grumble.css">
    <link rel="stylesheet" type="text/css" href="css/paster.css">
  </head>

  <body "width:1440px">
    <?php
        require("common_nav.php");
    ?>

    <div class="container-fluid">
        <div id = "hp_container" style = "margin-top:20px;">
          <div id = "bgDiv" ></div>
          <div>
    </div><!-- /.container -->
    <script src = "js/jquery-1.11.1.min.js"></script>
    <script src = "js/bootstrap.min.js"></script>
</body>
</html>