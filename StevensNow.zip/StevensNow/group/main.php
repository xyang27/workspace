<!DOCTYPE html>
  <html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Stevens Now</title>

    <!-- Bootstrap core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/groupmain.css" rel="stylesheet">
    <!-- Custom styles for this template -->
  </head>

  <body "width:1440px">
    <?php
        require("../common_nav.php");
    ?>
    <div class = "container-fluid">
      <div class = "row">
        <div class = "col-lg-2 sidebar">
          <ul class="nav nav-pills nav-stacked" role="tablist">
            <li role="presentation" class="active"><a href="">Group</a></li>
            <li role="presentation"><a id="create_group" href="">Create Group </a></li>
            <li role="presentation"><a id="search_group" href="">Search Group </a></li>
            <li role="presentation"><a id="my_create_group" href="">My Create Group </a></li>
            <li role="presentation"><a id="my_join_group" href="">My Join Group </a></li>  
          </ul>
        </div>

        <div class = "col-lg-9 main" id="group_main">
        
        </div>

      </div>
    </div>

    <script src = "../js/jquery-1.11.1.min.js"></script>
    <script src = "../js/jquery.validate.min.js"></script>
    <script src = "../js/bootstrap.min.js"></script>
    <script type="text/javascript">
      $("#create_group").click(function(e){
          e.preventDefault();
          $("#group_main").empty();
          $.get("create.html",function(d,s){
            $("#group_main").append(d);
          });
      });

      $("#my_create_group").click(function(e){
          e.preventDefault();
          $("#group_main").empty();
          $.get("display.html",function(d,s){
            $("#group_main").append(d);
          });
      });

    </script>
</body>
</html>