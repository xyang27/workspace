<?php
	class Group
	{
		public $name;
		public $description;
		public $create_time;

		static public $Unverified = -1;
		static public $GroupCreator = 0;
		static public $GroupManager = 1;
		static public $GroupRegularMember = 2;
		
		static public $group_columns = array(
				"name",
				"description",
				"create_time"
			);

		public function __construct($n, $d, $c)
		{
			$this->name = $n;
			$this->description  = $d;
			$this->create_time = $c;
		}

		public function GetValues()
		{
			$res = array(
				$this->name,
				$this->description,
				$this->create_time
				);
			return $res;
		}
	}

	class UserInGroup
	{
		public $id_user;
		public $id_group;
		public $type;

		static public $user_in_group_columns = array(
				"id_user",
				"id_group",
				"type"
			);

		public function __construct($u, $g, $t)
		{
			$this->id_user = $u;
			$this->id_group  = $g;
			$this->type = $t;
		}

		public function GetValues()
		{
			$res = array(
				$this->id_user,
				$this->id_group,
				$this->type
				);
			return $res;
		}
	}
?>