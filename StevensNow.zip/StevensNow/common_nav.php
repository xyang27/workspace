<nav class="navbar navbar-inverse" role="navigation">
      <div class="container-fluid">
          <div class = "navbar-header">
            <a class = "navbar-brand" href="main.php">Stevens Now</a>
          </div>
              <?php
            session_start();
            if (isset($_SESSION["username"])) {
              echo '<div class="navbar-text collapse navbar-collapse navbar-right">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">'.$_SESSION["username"].'<span class="caret"></span></a>
            <ul class="dropdown-menu" role="menu">
              <li><a href="#">Action</a></li>
              <li><a href="#">Another action</a></li>
              <li><a href="#">Something else here</a></li>
              <li class="divider"></li>
              <li><a href="#">Separated link</a></li>
              <li class="divider"></li>
              <li><a href="user_log_off.php">Log Off</a></li>
            </ul>
          </div>
          <p class="navbar-text navbar-right">Welcome :</p>
          <input type="hidden" id="id_user" name="id_user" value="'.$_SESSION["id_user"].'">';

            }else{
                echo '<form class="navbar-form navbar-right" action="user_sign_in.php" method="post">
              <div class="form-group">
                <input type="text" id="username" name="username" class="form-control" placeholder="Username">
              </div>
              <div class="form-group">
                <input type="password" id="password" name="password"  class="form-control" placeholder="Password">
              </div>
              <button type="submit"class="btn btn-default">Sign In</button>
              
              <a href = "signup.php" class="btn btn-default navbar-btn">Sign Up</a>
            </form>';
            }
            ?>
       </div>
    </nav>