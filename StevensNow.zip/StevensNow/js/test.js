$(document).ready(function(){
	
	// var p1 = paster({
	// 	position:{
	// 		top:"30%",
	// 		left:"30%"
	// 	},
	// 	opacity:"1"
	// });


	// $("#hp_container").append(p1.getContent());



	// p1.pushItem({
	// 	anchor:{
	// 		"href":"www.baidu.com",
	// 		"text":"hello world"	
	// 	},
	// 	description:"Hello Hello"
	// });
	
	// p1.setHeight(p1.getHeight());

	//var paster1 = paster({});
	//var paster1 = $("<div class='poster_container'><div class='poster_outer'><div class='poster_inner'></div></div></div>");
	
	//var paster1 = paster();
	
	//var maker = createMarker("aaa","50%","50%");
	var p1 = paster({
		text:"2014 Fall International Students Orientation! ",
		position:{
			top:"30%",
			left:"30%"
		},
		opacity:"1"
	});

	var p2 = paster({
		text: "CS546 Week1 ",
		// pos:{
		// 	top:"30%",
		// 	left:"30%"
		// },
		opacity:"1"
	});

	var p3 = paster({
		text: "Team SHEN group study ",
		opacity:"1"
	});
	p3.insertText("Group Meeting");

	makeEverythingTogether($("#hp_container"), p1, {top:"165px", left:"672px"}, "1");
	makeEverythingTogether($("#hp_container"), p2, {top:"234px", left:"526px"}, "1");
	makeEverythingTogether($("#hp_container"), p3, {top:"351px", left:"403px"}, "2");

	// var p1 = paster({
	// 	text:"Video Game Save the World",
	// 	pos:{
	// 		top:"40%",
	// 		left:"30%"
	// 	}
	// });
	// $("body").append(p1.getContent());
	// p1.setHeight(p1.getHeight());



	//paster1.setEverything();

	//$("body").append(paster1.create({top:"30%", left:"30%"},{text:"Hello World", href:"http://www.google.com"}));
	//$("body").append(paster1.create({top:"50%", left:"50%"},{text:"Stevens Now!", href:"http://www.stevens.edu/sit/"}));
	//var a = "Hello World";
	
	// $("body").append(createMarker("cs_hst2","50%","50%"));
	
	// $("#cs_hst2").grumble({
	// 	text: '2', 
	// 	angle: 0, 
	// 	distance: 10,
	// 	opacity: .8,
	// 	color: "#3366CC"
	// });



	// $("#cs_hst2").grumble('adjust',{text:"0.1"});
	// $("#cs_hst2").grumble('adjust',{opacity:0.1});

	// $("#cs_hst2").grumble('show',1000);

	//$("#cs_hst2").grumble('show',1000);
	//$("#cs_hst2").grumble('adjust',{text: "2"});
	//$("#cs_hst2").grumble('hide');

	//$("#cs_hst2").grumble("show",800);
	//$("#cs_hst2").delay(3000);
	//$("#cs_hst2").grumble('adjust',{opacity:0.1});

	// $("#cs_hst2").grumble('show',1000);
	// //$("#cs_hst2").grumble('adjust',{opacity:0.3});
	// setTimeout(function(){
	// 	$("#cs_hst2").grumble('adjust',{opacity:0.5});
	// }, 2000);
	
	// var timer = null;
	// $(document).mousemove(function(event){
	// 	$("#cs_hst2").grumble("show",800);
		
	// 	clearTimeout(timer);

	// 	timer = setTimeout(function(event){
	// 		$("#cs_hst2").grumble('adjust',{opacity:0.5});
	// 	},1000);
	// });

	// var timer = null;
	// $(document).mousemove(function(event){
	// 	$("#cs_hst1").css({"visibility":"visible", "opacity":"1"});
	// 	$("#cs_hst2").css({"visibility":"visible", "opacity":"1"});
		
	// 	clearTimeout(timer);
	// 	timer = setTimeout(function(){
	// 		$("#cs_hst1").css({"opacity":"0"});
	// 		$("#cs_hst2").css({"opacity":"0"});
	// 	},2000);
	// });


	function createMarker(id, top, left)
	{
		return $("<div></div>",{
			"id":id,
			"class":"sh_hst",
			"css":{
				"top": top,
				"left": left,
				"visibility": "visible",
				"opacity": "1",
				"-webkit-transition" : "opacity 800ms ease 0s"
			}
		}).append( $("<div></div>",{"class":"sh_hto"}).append($("<div></div>",{"class":"hp_hot"})));
	}

	function makeEverythingTogether(context, paster, pos, num){
		var m = createMarker("",pos.top,pos.left);
		context.append(m);
		context.append(paster.getContent());

		m.grumble({
			text: num, 
			angle: 0, 
			distance: 25,
			opacity: .8,
			color: "white"
		});

		m.grumble("show",1000);

		paster.setHeight(paster.getHeight());
		paster.setPosition({top:pos.top, left:pos.left}).content.css({"margin-left" : "35px"});

		// m.mouseenter(function(){
		// 	$(this).css("opacity",1);
		// 	setTimeout(function(){paster.setOpacity(1);},500);
		// });

		// m.mouseleave(function(){
		// 	$(this).css("opacity",0);
		// 	setTimeout(function(){paster.setOpacity(0);},500);
		// });
	}
});