

$(document).ready(function(){
	checkUserName();
});

function checkUserName()
{
	$("#username").blur(function(){
		var un = $(this).val();
		var url = "check_user_name.php?un="+un;
		$.get(url, function(data, status){
			if (data >0) 
			{
				$("#checkRes").text("X");
			}else{
				$("#checkRes").text("O");
			}
		});
	});
}