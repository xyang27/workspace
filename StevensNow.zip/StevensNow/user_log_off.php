<?php

	session_start();
	if (isset($_SESSION["username"])) {
		SignOff();
	}else{
		header("location: main.php");
	}
	function SignOff()
	{
		session_destroy();
		header("location: main.php");
	}
?>