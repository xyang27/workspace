<?php
	class User
	{
		public $username;
		public $password;
		public $email;
		public $type;

		static public $user_columns = array(
				"username",
				"password",
				"email",
				"type"
			);

		public function __construct($u, $p, $e, $t)
		{
			$this->username = $u;
			$this->password  = $p;
			$this->email = $e;
			$this->type = $t;
		}

		public function GetValues()
		{
			$res = array(
				$this->username,
				$this->password,
				$this->email,
				$this->type
				);
			return $res;
		}
	}
?>