<?php
	$a = array('name'=>"zhizhuoding");
	echo json_encode($a);
?>