<?php

	include("../include/databaseClassMySQLi.php");
	include("../include/common.php");
	include("../include/DataStructure/user.php");

	if (isset($_REQUEST["group_name"]) && isset($_REQUEST["id_user"])) {
		$db = new database();
		$db->connect();
		$query = "SELECT * FROM `group`, `user_in_group` WHERE user_in_group.type = 0 and group.id_group = user_in_group.id_group and group.name = '".$_REQUEST["group_name"]."' and user_in_group.id_user =".$_REQUEST["id_user"]."";
		$db->send_sql($query);
		$res = $db->send_sql($query);
		$count = mysqli_num_rows($res);
		if ($count > 0) {
			echo "false";
		}else{
			echo "true";
		}
	}
?>