<?php
	include("../include/databaseClassMySQLi.php");
	include("../include/common.php");
	include("/group/group.php");

	function display($id)
	{

	}

?>	
