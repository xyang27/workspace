var paster = (function($){
	
	var p = null;

	var settings = {
		fontSize : "small",
		fontColor : "#fff",
		backgroundColor : 'grey',
		tmpl: "<a class='inner_anchor'><p class = 'inner_p'>HelloWorld</p><div class='paster_bg'><div class='paster_border'></div></div></a>"
	};

	var applyCss = function(){
		p.css({"color": settings.fontColor, "font-size": settings.fontSize});
	}

	var setPosition = function(pos){
		p.css("top", pos.top);
		p.css("left", pos.left);
		p.find(".paster_border").css({"height":"30px"});
	}

	var setHeight = function(){
		//p.find("paster_border").css({height:"20px"});
	}

		var setHeight = function(){
		//p.find("paster_border").css({height:"20px"});
	}

	// var setAnchor = function(anchor){
	// 	var a = $("<a></a>");
	// 	a.attr({
	// 		"href":anchor.href,
	// 		"class":"inner_anchor"
	// 	}).text(anchor.text);

	// 	p.find(".poster_inner").append(a);
	// }

	return function(){
		return {
			create : function(pos,a){
				p = $(settings.tmpl);			
				
				applyCss();
				// setHeight();

				if (pos) {
					setPosition(pos);
				};

				// if (a) {
				// 	setAnchor(a);
				// };
				return p;
			},
			setEverything : function(){
				applyCss();
				setHeight();
			}
		}
	}

})(jQuery);