<?php

	include("./include/databaseClassMySQLi.php");
	include("./include/common.php");
	include("./include/DataStructure/user.php");
	
	if (isset($_POST["sign_username"]) && isset($_POST["sign_password"]) 
		&& isset($_POST["email"]) ) {
		$user = new User($_POST["sign_username"], $_POST["sign_password"], $_POST["email"], 1);
		SignUp($user);
	}


	function SignUp($u)
	{
		$db = new database();
		$db->connect();
		$query = InsertQuery("user", User::$user_columns, $u->GetValues());
		echo $query;
		$db->send_sql($query);
		header("location: main.php");
	}
?>