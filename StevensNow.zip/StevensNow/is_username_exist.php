<?php

	include("./include/databaseClassMySQLi.php");
	include("./include/common.php");
	include("./include/DataStructure/user.php");

	if (isset($_REQUEST["username"])) {
		$db = new database();
		$db->connect();
		$query = "SELECT * FROM user WHERE username = '".$_REQUEST["username"]."'";
		$db->send_sql($query);
		$res = $db->send_sql($query);
		$count = mysqli_num_rows($res);
		if ($count > 0) {
			echo "false";
		}else{
			echo "true";
		}
	}
?>