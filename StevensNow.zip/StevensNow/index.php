<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8"/>
	<title>Stevens Now</title>
</head>
<body>
	<?php
		session_start();
		if (isset($_SESSION["username"])) {
			echo "User Name: ".$_SESSION["username"]."<br>";
		}else{
			echo "Hello World! Stevens Now : ) <br>";
		}
	?>
	<a href ="signup.html">Sign Up</a>
	<a href ="signin.html">Sign In</a>
	<a href ="user_sign_off.php">Sign Off</a>
</body>
</html>