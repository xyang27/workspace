<?php
	include("../include/databaseClassMySQLi.php");
	include("../include/common.php");
	include("group.php");
 	session_start();
 	$userid = $_SESSION["id_user"];
 	
 	if (isset($userid) && isset($_POST["create_group_name"]) && isset($_POST["create_group_des"])) {
 		$date = date("Y-m-d");
 		//echo $userid." ".$_POST["create_group_name"]." ".$_POST["create_group_des"]." ".$d;
 		$g = new Group($_POST["create_group_name"], $_POST["create_group_des"],$date);
 		create($g);
 	}


 	function create($g){
		global $userid;
		
		$db = new database();
		$db->connect();
		$query1 = InsertQuery("group", Group::$group_columns, $g->GetValues());
		$db->send_sql($query1);
		$group_id = $db->insert_id();

		$uig = new UserInGroup($userid, $group_id, Group::$GroupCreator);
		$query2 = InsertQuery("user_in_group", UserInGroup::$user_in_group_columns, $uig->GetValues());
		$db->send_sql($query2);

		header("location: main.php");
 	}
?>