<?php

	session_start();

	if (isset($_SESSION["username"])) {
		SignOff();
	}
	
	function SignOff()
	{
		session_destroy();
		header("location: index.php");
	}
?>