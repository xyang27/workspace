<?PHP 
	//INSERT INTO `group`(`name`, `description`, `create_time`) VALUES ('cs546','blabla','2014-1-1')
	function InsertQuery($tn, $columns, $values)
	{
		$query = "INSERT INTO `".$tn."` (";
		$col_size = count($columns);
		
		for ($i=0; $i != $col_size - 1; $i++) { 
			$query .= "`".$columns[$i]."`,";
		}
		
		$query .= "`".$columns[$i]."`";
		$query .= ") VALUES ( ";

		$val_size = count($values);
		for ($i=0; $i != $val_size - 1; $i++) { 
			$query .= "'".$values[$i]."'".",";
		}
		$query .= "'".$values[$i]."');";
		return $query;
	}

	function SuperExplode($delimiter, $str)
	{
		$tokens = $delimiter;
		$tok = strtok($str, $tokens);
		$res = array();
		while ($tok !== false) {
			array_push($res, $tok);
		   	$tok = strtok($tokens);
		}
		return $res;
	}
	
?>