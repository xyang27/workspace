<?php
	include("./include/databaseClassMySQLi.php");
	if (isset($_GET["un"])) {
		$db = new database();
		$db->connect();
		$query = "SELECT * from user where username = '".$_GET["un"]."';";
		$res = $db->send_sql($query);
		$count = mysqli_num_rows($res);

		if ($count > 0) {
			echo 1;
		}else{
			echo 0;
		}
	}

?>