var paster = (function($){

	return function(spec){
		
		var settings = {
			tmpl: "<div class='paster_container'><p class = 'inner_p'></p><div class='paster_bg'><div class='paster_border'></div></div></div>",
			textTmpl: "<p class = 'inner_p'></p>"
		};

		var that = {
			content : $(settings.tmpl),
			postion:{
				top : "0%",
				left : "0%"
			},
			font:{
				size: "10px",
				color: "#fff"
			},
			backgroundColor: "black",
			text:"",
			opacity:"1"
		};

		that = $.extend({}, that, spec);

		var getContent = function(){
			setText(that.text);
			setPosition(that.postion);
			setFont(that.font);
			setBgColor(that.backgroundColor);
			setOpacity(that.opacity);
			return that.content;
		};

		var setText = function(text){
			if (text) 
			{
				that.content.find(".inner_p").first().text(text);
			};
			return that;
		};

		var setPosition = function(pos){
			that.content.css({
				top: pos.top,
				left: pos.left
			});
			return that;
		};

		var setHeight = function(h){
			that.content.find('.paster_bg').css("height", h+10);
			that.content.find('.paster_border').css("height", h+9);
			return that;
		}

		var getHeight = function(){
			return that.content.height();
		};

		var setFont = function(f){
			that.content.css({
				"font-size" : f.size,
				"color" : f.color
			});
			return that;
		};

		var setBgColor = function(c){
			that.content.find(".paster_bg").css({
				"background" : c
			});
			return that;
		};

		var setOpacity = function(o){
			that.content.css({"opacity":o});
			return that;
		};

		var insertText = function(t){
			var newOne = $(settings.textTmpl).text(t);
			var p = that.content.find("p").last().after(newOne);
			return that;
		}

		that.getContent = getContent;
		that.setText = setText;
		that.setPosition = setPosition;
		that.getHeight = getHeight;
		that.setHeight = setHeight;
		that.setFont = setFont;
		that.setBgColor = setBgColor;
		that.setOpacity = setOpacity;
		that.insertText = insertText;

		return that;
	};	
})(jQuery);